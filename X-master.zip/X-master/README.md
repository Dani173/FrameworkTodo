# X
PHP framework. We use this framework to study design patterns. 

## Development mode


### Configuration

We have  the file *app/config.json* to do the task.
If we want to change our database configuration we can do it in two environments:
>..*production, we use the array key **dbconf_pro**
>..*development, we use the array key **dbconf_dev**

