<?php
/**
 * Created by PhpStorm.
 * User: linux
 * Date: 10/01/19
 * Time: 16:22
 */

namespace X\App\Models;


use X\Sys\Model;

class mPanel extends Model
{
    public function __construct(){
        parent::__construct();

    }

    /*public function login($nom,$pass){


    }*/
}