<?php

	namespace X\App\Models;

	use \X\Sys\Model;

	class mError extends Model{
		public function __construct(){
			parent::__construct();
			
		}
	}