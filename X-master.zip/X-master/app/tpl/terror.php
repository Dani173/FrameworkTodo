<?php 
	include 'head_common.php';
	?>
<body>
	<h1><?= $this->page; ?></h1>
	
<?php 
	include 'footer_common.php';
?>