<footer>

    Copyright (c) 2003 Dani Gonzalez
    All Rights Reserved

</footer>
</body>
</html>