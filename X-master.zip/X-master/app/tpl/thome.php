<?php 
	include 'head_common.php';
	?>

    <body class="bindex">
    <h1>Bienvenido a TODOList</h1>
    <div>
        <a href="users">Login</a>
        <a href="reg">Registrarse</a>
    </div>

<?php 
	include 'footer_common.php';
?>