<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= $this->page;?></title>
	<link rel="stylesheet" href="<?= 'pub/css/bootstrap.min.css'; ?>">
        <script type="text/javascript" src="pub/app.js"></script>
</head>